READER-FACING ANALYSIS DIAGRAM

This revised figure explains how the reported revisit and coverage measures
are derived. It replaces the project-plan checklist with common assumptions,
the altitude variable, observation geometry, observation windows and the
three quantities readers will see in the results. The unscaled timeline
illustrates the end-of-window to next-start definition of revisit gap.
It contains no simulated numerical results.

RUN ON YOUR MAC
1. Replace the previous analysis_workflow.py in your map project folder with
   this new script.
2. In Terminal, enter that folder and activate the existing environment:
   source .venv/bin/activate
3. Run:
   python analysis_workflow.py
4. Open:
   open figures/analysis_workflow.pdf

Only Matplotlib is required; it is already part of your map environment.
The package includes the finished PDF and PNG for immediate use.

OVERLEAF
Replace figures/analysis_workflow.pdf with the revised PDF. Place the figure
near the start of the Analysis Method section, and use this caption:

\begin{figure}[htbp]
\centering
\includegraphics[width=0.95\linewidth]{figures/analysis_workflow.pdf}
\caption{Analysis structure linking the four altitude cases to geometric
observation windows, per-target revisit gaps, and daily regional coverage.
The schematic timeline defines revisit as the interval from the end of one
observation window to the start of the next.}
\label{fig:workflow}
\end{figure}

Use the label only once. Introduce the figure in the text, for example:
Figure~\ref{fig:workflow} summarises how the common observation model and
altitude-dependent trajectories are converted into the performance measures
used in the comparison.

This is a methodology figure supporting the results; update its wording if
the observation model or reported metrics change during implementation.
