"""Draw a reader-facing analysis diagram using Matplotlib.
Run: python analysis_workflow.py
Creates figures/analysis_workflow.pdf and .png beside this script.
The diagram explains derived quantities; it does not calculate orbit results.
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUTPUT = Path(__file__).resolve().parent / "figures"
INK, TEAL, GREY = "#203746", "#087f8c", "#5c6b73"


def main():
    OUTPUT.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":10,
                         "pdf.fonttype":42, "ps.fonttype":42})
    fig, ax = plt.subplots(figsize=(9.4, 10.3), facecolor="white")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 12.0)
    ax.axis("off")

    def box(x, y, w, h, title, detail="", fill="#edf6f7", edge=TEAL,
            title_size=11, detail_size=9.3):
        ax.add_patch(FancyBboxPatch((x-w/2,y-h/2), w, h,
                                   boxstyle="round,pad=0.035,rounding_size=0.09",
                                   facecolor=fill, edgecolor=edge, linewidth=1.1))
        ax.text(x, y+h*0.23, title, ha="center", va="center",
                fontsize=title_size, fontweight="bold", color=INK)
        if detail:
            ax.text(x, y-h*0.13, detail, ha="center", va="center",
                    fontsize=detail_size, color=GREY, linespacing=1.4)

    def arrow(a,b,vertices=None):
        if vertices:
            xs,ys=zip(*vertices)
            ax.plot(xs,ys,color=TEAL,linewidth=1.1)
            a=vertices[-1]
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle="-|>",mutation_scale=12,
                                    linewidth=1.1,color=TEAL))

    ax.text(0.15,11.65,"FROM ORBIT GEOMETRY TO REVISIT PERFORMANCE",
            fontsize=15.2,fontweight="bold",color=INK,va="top")
    ax.text(0.15,11.18,"Analysis structure for the Central Europe altitude comparison",
            fontsize=10.3,color=GREY,va="top")

    box(2.55,10.15,4.65,1.15,"Common observation model",
        "Target region and grid; sensor angular field of view\nInclination, epoch and initial orbital phase",
        fill="#f2f4f5",edge="#89969c",detail_size=8.9)
    box(7.55,10.15,4.35,1.15,"Variable: initial orbital altitude",
        "400  |  500  |  600  |  700 km\nOne initially circular orbit per case")
    arrow((2.55,9.53),(4.25,9.01))
    arrow((7.55,9.53),(5.75,9.01))
    box(5,8.45,7.3,1.05,"Time-tagged spacecraft positions",
        "GMAT propagation with a common force model\nPositions and targets expressed in a consistent reference frame")
    arrow((5,7.88),(5,7.48))
    box(5,6.90,7.3,1.05,"Target visibility as a function of time",
        "Inside the sensor field of view AND not occulted by Earth\nSame target grid and observation rules for every altitude")
    arrow((5,6.33),(5,5.95))

    box(5,5.14,7.3,1.55,"", "",fill="#f5f9fa")
    ax.text(5,5.67,"Observation windows and revisit gaps",ha="center",
            va="center",fontsize=11,fontweight="bold",color=INK)
    # Schematic timeline, intentionally unscaled: demonstrates the metric,
    # without presenting fabricated simulation values.
    yy=5.04
    ax.plot([2.1,7.9],[yy,yy],color="#acb7bd",linewidth=1,zorder=2)
    ax.plot([2.45,3.45],[yy,yy],color=TEAL,linewidth=7,solid_capstyle="butt")
    ax.plot([6.15,7.15],[yy,yy],color=TEAL,linewidth=7,solid_capstyle="butt")
    ax.text(2.95,4.80,"Window k",ha="center",fontsize=8.5,color=GREY)
    ax.text(6.65,4.80,"Window k+1",ha="center",fontsize=8.5,color=GREY)
    ax.add_patch(FancyArrowPatch((3.45,5.20),(6.15,5.20),arrowstyle="<->",
                                mutation_scale=9,color="#a64b34",linewidth=1.0))
    ax.text(4.8,5.25,"End-to-start gap",ha="center",va="bottom",
            fontsize=8.7,color="#a64b34")
    ax.text(5,4.55,"Schematic only; timeline not to scale",ha="center",
            fontsize=7.8,color=GREY)

    # Branch to three distinct result measures, then reconverge.
    arrow((5,4.32),(5,3.80))
    ax.plot([1.75,8.25],[3.80,3.80],color=TEAL,linewidth=1.1)
    for x in [1.75,5,8.25]:
        arrow((x,3.80),(x,3.53))
    box(1.75,2.95,3.0,1.05,"Mean revisit gap",
        "Typical complete gap\nfor each target",title_size=10.3,detail_size=8.8)
    box(5,2.95,3.0,1.05,"Maximum revisit gap",
        "Longest complete gap\nobserved for each target",title_size=10.1,detail_size=8.8)
    box(8.25,2.95,3.0,1.05,"Daily regional coverage",
        "Area-weighted fraction\nobserved at least once per day",title_size=9.7,detail_size=8.6)
    for x in [1.75,5,8.25]:
        ax.plot([x,x],[2.37,2.11],color=TEAL,linewidth=1.1)
    ax.plot([1.75,8.25],[2.11,2.11],color=TEAL,linewidth=1.1)
    arrow((5,2.11),(5,1.84))
    box(5,1.24,9.5,1.10,"Altitude comparison and interpretation",
        "Geographic maps and regional summaries, with insufficient observations flagged\n"
        "Conclusions assessed against verification, numerical convergence and scenario sensitivity",
        fill="#e1f0ee",detail_size=9)
    ax.text(0.2,0.27,"Access denotes geometric opportunity; clouds, scheduling and image usability are outside the baseline.",
            fontsize=8.1,color=GREY)
    fig.subplots_adjust(left=0.02,right=0.99,bottom=0.02,top=0.99)
    for ext in ["pdf","png"]:
        path=OUTPUT/f"analysis_workflow.{ext}"
        fig.savefig(path,dpi=220,bbox_inches="tight",pad_inches=0.15)
        print(f"Saved: {path}")
    plt.close(fig)


if __name__ == "__main__":
    main()
