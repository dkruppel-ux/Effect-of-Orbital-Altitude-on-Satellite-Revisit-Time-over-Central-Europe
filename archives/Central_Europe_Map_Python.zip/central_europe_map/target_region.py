"""Draw a configurable target region and export its satellite-analysis grid.

Run: python target_region.py
Dependencies: numpy, matplotlib, geopandas (see requirements.txt).
Boundaries: Natural Earth Admin 0, 1:50m. Internet needed on first run only.
The default rectangle is a provisional study area, not an official definition
of Central Europe. It includes all surfaces inside the box, including water.
"""
from pathlib import Path
from urllib.request import urlopen
import hashlib
import json

import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
import matplotlib.patheffects as pe
import numpy as np

# EDIT THESE SETTINGS BEFORE FINALISING YOUR STUDY.
LON_MIN, LON_MAX = 5.0, 25.0       # degrees east
LAT_MIN, LAT_MAX = 45.0, 55.0     # degrees north
GRID_STEP_DEG = 0.5              # cell-centred latitude/longitude grid

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
FIGURES = BASE / "figures"
URL = ("https://naturalearth.s3.amazonaws.com/50m_cultural/"
       "ne_50m_admin_0_countries.zip")


def main():
    if not (-180 <= LON_MIN < LON_MAX <= 180
            and -90 < LAT_MIN < LAT_MAX < 90 and GRID_STEP_DEG > 0):
        raise ValueError("Check the region bounds and positive grid spacing.")
    nx_float = (LON_MAX - LON_MIN) / GRID_STEP_DEG
    ny_float = (LAT_MAX - LAT_MIN) / GRID_STEP_DEG
    if not (np.isclose(nx_float, round(nx_float))
            and np.isclose(ny_float, round(ny_float))):
        raise ValueError("Each region span must be divisible by GRID_STEP_DEG.")
    nx, ny = round(nx_float), round(ny_float)
    if nx < 1 or ny < 1:
        raise ValueError("The region must contain at least one grid cell.")
    DATA.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    archive = DATA / "ne_50m_admin_0_countries.zip"
    if not archive.exists():
        print("Downloading Natural Earth country boundaries...")
        try:
            with urlopen(URL, timeout=60) as response:
                content = response.read()
            temporary = archive.with_suffix(".download")
            temporary.write_bytes(content)
            temporary.replace(archive)
        except OSError as exc:
            raise RuntimeError(
                f"Could not download the map. Try again with internet access, "
                f"or save the Natural Earth ZIP manually to {archive}."
            ) from exc
    countries = gpd.read_file(archive).to_crs("EPSG:4326")

    # Use cell centres, not cell edges. Default settings give 40 x 20 = 800 targets.
    lons = LON_MIN + (np.arange(nx) + 0.5) * GRID_STEP_DEG
    lats = LAT_MIN + (np.arange(ny) + 0.5) * GRID_STEP_DEG
    lon_grid, lat_grid = np.meshgrid(lons, lats)
    lon, lat = lon_grid.ravel(), lat_grid.ravel()

    # Relative cell areas on a sphere: d_lon * (sin(lat_north)-sin(lat_south)).
    # Normalise to sum to one for area-weighted regional summaries later.
    half_step = GRID_STEP_DEG / 2
    weight = np.deg2rad(GRID_STEP_DEG) * (
        np.sin(np.deg2rad(lat + half_step))
        - np.sin(np.deg2rad(lat - half_step))
    )
    weight /= weight.sum()
    targets = np.column_stack((np.arange(1, len(lon) + 1), lon, lat, weight))
    csv_path = DATA / "target_grid.csv"
    np.savetxt(csv_path, targets, delimiter=",", comments="",
               header="target_id,longitude_deg,latitude_deg,area_weight",
               fmt=["%d", "%.6f", "%.6f", "%.12f"])

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, ax = plt.subplots(figsize=(10, 7.2))
    ax.set_facecolor("#edf4f7")
    # Only plot surrounding countries; this does not clip the analysis grid to land.
    nearby = countries.cx[LON_MIN - 4:LON_MAX + 4, LAT_MIN - 3:LAT_MAX + 3]
    nearby.plot(ax=ax, facecolor="#e2e5e5", edgecolor="#737d85", linewidth=0.6)
    ax.add_patch(Rectangle((LON_MIN, LAT_MIN), LON_MAX-LON_MIN, LAT_MAX-LAT_MIN,
                          facecolor="#16858a", alpha=0.09, edgecolor="none", zorder=2))
    ax.scatter(lon, lat, s=4, color="#137780", alpha=0.7, linewidths=0, zorder=3)
    ax.add_patch(Rectangle((LON_MIN, LAT_MIN), LON_MAX-LON_MIN, LAT_MAX-LAT_MIN,
                          fill=False, edgecolor="#b34b32", linewidth=1.8, zorder=4))
    # Geographic labels provide orientation only; they do not define the region.
    labels = {
        "Germany": (10.5, 51.0), "Poland": (19.0, 52.0),
        "Czechia": (15.4, 49.8), "Austria": (13.1, 47.6),
        "Switzerland": (8.2, 46.7), "Slovakia": (19.4, 48.7),
        "Hungary": (19.4, 47.1), "Slovenia": (14.7, 46.1),
        "France": (3.2, 48.0), "Italy": (10.4, 44.0),
        "Romania": (25.3, 46.0), "Denmark": (10.0, 56.0),
    }
    for name, (x, y) in labels.items():
        if LON_MIN-2.5 < x < LON_MAX+2.5 and LAT_MIN-1.8 < y < LAT_MAX+1.8:
            ax.text(x, y, name, ha="center", va="center", fontsize=8.5,
                    color="#28343e", zorder=5,
                    path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])
    ax.set_xlim(LON_MIN-2.5, LON_MAX+2.5)
    ax.set_ylim(LAT_MIN-1.8, LAT_MAX+1.8)
    ax.set_aspect(1 / np.cos(np.deg2rad((LAT_MIN+LAT_MAX)/2)))
    ax.set_xlabel("Longitude (degrees east)")
    ax.set_ylabel("Latitude (degrees north)")
    ax.grid(color="#9baab0", linestyle=":", linewidth=0.5, alpha=0.6)
    ax.set_axisbelow(True)
    ax.set_title("Central Europe | Target region and sampling grid", loc="left",
                 fontsize=15, fontweight="bold", pad=30)
    ax.text(0, 1.015,
            f"Provisional rectangular study area: {LON_MIN:g}–{LON_MAX:g}°E, "
            f"{LAT_MIN:g}–{LAT_MAX:g}°N  ·  {len(lon):,} targets",
            transform=ax.transAxes, color="#52616b", fontsize=9)
    ax.legend(handles=[Patch(facecolor="none", edgecolor="#b34b32",
                             label="Study boundary"),
                       Line2D([], [], marker="o", linestyle="none", color="#137780",
                              markersize=4, label=f"{GRID_STEP_DEG:g}° cell-centre grid")],
              loc="lower left", framealpha=0.96, fontsize=8.5)
    fig.text(0.10, 0.035,
             "Boundaries: Natural Earth, Admin 0 (1:50m). Coordinates: WGS 84.\n"
             "The study boundary is user-defined; grid includes land and water.",
             fontsize=8, color="#52616b")
    fig.subplots_adjust(left=0.10, right=0.97, bottom=0.15, top=0.86)
    for extension in ("pdf", "png"):
        fig.savefig(FIGURES / f"target_region.{extension}", dpi=300, bbox_inches="tight")
    plt.close(fig)
    metadata = {
        "bounds_lon_lat": [LON_MIN, LAT_MIN, LON_MAX, LAT_MAX],
        "grid_spacing_deg": GRID_STEP_DEG, "grid_convention": "cell centres",
        "target_count": len(lon), "crs": "EPSG:4326", "land_only": False,
        "weights": "normalised spherical cell areas, not ellipsoidal areas",
        "boundary_source_url": URL,
        "boundary_zip_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    }
    (DATA / "study_settings.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Saved {len(lon)} targets: {csv_path}")
    print(f"Overleaf figure: {FIGURES / 'target_region.pdf'}")
    print(f"Preview: {FIGURES / 'target_region.png'}")


if __name__ == "__main__":
    main()
