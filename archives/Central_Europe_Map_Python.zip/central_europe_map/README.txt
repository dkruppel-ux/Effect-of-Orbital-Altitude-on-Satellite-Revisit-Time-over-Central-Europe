CENTRAL EUROPE TARGET-REGION MAP

1. Install dependencies:
   python -m pip install -r requirements.txt

2. Run:
   python target_region.py

Outputs are saved relative to the script (not your terminal directory):
  figures/target_region.pdf  Vector map for Overleaf.
  figures/target_region.png  Image preview.
  data/target_grid.csv       Target IDs, longitude, latitude and area weights.
  data/study_settings.json   Bounds, spacing, source and data checksum.

The included map and grid use provisional bounds 5--25 degrees E,
45--55 degrees N and a 0.5-degree grid (800 cell-centre points).
This is an explicit rectangular study area, not an official definition of
Central Europe. It contains both land and water. Change the five settings
near the top of target_region.py to adjust the region or resolution.
Keep this region and target grid identical in all four altitude cases.

Equal degree spacing does not give equal cell area. The CSV includes
normalised spherical cell-area weights for later regional aggregation.
The 0.5-degree grid is an initial choice; check finer grids before reporting
final coverage and worst-case revisit results.

Natural Earth Admin 0, 1:50m country boundaries are included as a cached ZIP.
They are used for map context only, not for target selection.
Source: https://www.naturalearthdata.com/downloads/50m-cultural-vectors/
Download: https://naturalearth.s3.amazonaws.com/50m_cultural/ne_50m_admin_0_countries.zip
Natural Earth data are public domain. Retain the source credit in the report.
With the cached ZIP present, the script runs offline. Without it, the first
run downloads it automatically.

OVERLEAF
Upload figures/target_region.pdf to the figures folder of your AIAA project.
Activate the corresponding commented figure block, or insert:

\begin{figure}[htbp]
\centering
\includegraphics[width=0.9\linewidth]{figures/target_region.pdf}
\caption{Provisional region of interest (5--25 degrees east, 45--55 degrees
north) and target locations on a 0.5-degree cell-centred grid.
Country boundaries: Natural Earth.}
\label{fig:region}
\end{figure}

The map contains no simulated satellite coverage or revisit results.
