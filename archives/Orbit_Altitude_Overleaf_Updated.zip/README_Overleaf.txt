UPDATED OVERLEAF REPORT

1. Unzip this package on your Mac.
2. In your EXISTING AIAA Overleaf project, upload
   Orbit_Altitude_Report_Updated.tex and the supplied figures folder.
3. Set Orbit_Altitude_Report_Updated.tex as the Main document in Overleaf's
   project settings (or paste its contents into your existing main .tex file).
4. Keep the new-aiaa.cls and support files already in your Overleaf project.
5. Recompile. The included PDF is a compiled preview of the revised report.

WHAT WAS UPDATED
- Completed abstract, introduction and conclusions for the analysed baseline.
- Explicit region, 800-point grid, sensor definition and observation geometry.
- WGS 84 target conversion, cone/horizon tests, window and metric definitions.
- Numerical results for the four 30-day cases.
- Input checks, analytic/direct geometry checks and 20 s coarsening diagnostic.
- Ten figure inclusions, with matching filenames and captions.
- Mean and maximum gap maps, daily coverage, distribution and supporting plots.
- Replaced all drafting prompts; nomenclature remains removed.

DATA TABLES
comparison_summary.csv and coarse_20s_summary.csv contain the numerical
summaries used in the report. analysis_metadata.json records input hashes,
geometry, software versions and input-check details. Raw trajectory files
remain in your Drive folder and are not included in this package.

SCOPE OF THE CONCLUSIONS
The current results are preliminary estimates from 10 s samples on a
0.5-degree target grid. The 20 s subsample is a coarsening diagnostic, not
a finer-time convergence test. Finer native GMAT sampling, geographic-grid
refinement, duration and initial-orientation tests remain outstanding.

The GMAT CSVs confirm epochs, frame labels and initial radii, but do not
record the full native initial-state, gravity and integrator configuration.
The report identifies the initial orbit setup as nominal and states that
the original GMAT scripts must be archived and checked before final release.
No claim of completed force-model audit or full mission validation is made.

NUMERICAL INTERPRETATION
700 km leads on regional mean gap and average daily coverage.
600 km has the shortest largest observed complete gap.
The long 500 km interruption is explicitly discussed and not treated as a
verified mission-lifetime bound. End-of-interval censored gaps are excluded
from complete-gap estimates and discussed as a limitation.
