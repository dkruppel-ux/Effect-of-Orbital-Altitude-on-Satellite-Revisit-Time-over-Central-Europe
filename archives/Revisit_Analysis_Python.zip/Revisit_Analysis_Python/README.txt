CENTRAL EUROPE REVISIT ANALYSIS — MAC GUIDE

WHAT THIS DOES
Reads your four GMAT trajectories and the included target grid. Calculates
observation windows, complete revisit gaps and daily area-weighted coverage
for the same idealised sensor in each case. Exports CSV tables and seven
figures, each as PDF and PNG. The initial outputs from your Drive files are
included; running the script regenerates them.

1. UNZIP
Double-click Revisit_Analysis_Python.zip. Open the extracted folder until
you see analyze_revisit.py, config.json, requirements.txt, data and figures.

2. ADD YOUR FOUR TRAJECTORIES
Download the CSVs from your Google Drive folder 'Orbit Project 1'.
Copy them into data/trajectories with these exact names:
trajectory_400km_30days.csv
trajectory_500km_30days.csv
trajectory_600km_30days.csv
trajectory_700km_30days.csv

Do not open and resave the trajectories in Excel; use the original CSVs.
The large raw trajectories are not duplicated in this download package.
The target grid and cached country boundaries ARE included.

3. OPEN TERMINAL IN THE PROJECT FOLDER
Type cd followed by one space. Drag the folder containing analyze_revisit.py
from Finder into Terminal. Press Return. Run ls to check the file is listed.

4. CREATE THE ENVIRONMENT (FIRST TIME IN THIS NEW FOLDER)
Run these commands one at a time:
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

A project environment previously created in a different folder is separate.
For this new folder, use the setup above. On later runs, just activate it:
source .venv/bin/activate

5. RUN
python analyze_revisit.py

The Terminal prints progress for 400, 500, 600 and 700 km, then generates
figures. Keep the window open until 'Finished' appears. Runtime depends on
your Mac; analysis uses roughly a few hundred MB of memory.

6. OPEN THE FIRST FIGURES
open figures/altitude_revisit.pdf
open figures/revisit_maps.pdf
open figures/daily_coverage.pdf

7. OPEN THE NUMERICAL SUMMARY
open results/comparison_summary.csv

The summary is small and can be viewed in Numbers/Excel. Keep the large
original GMAT trajectory CSV files unchanged.

8. USE IN OVERLEAF
Upload the desired PDF figures into the report project's figures folder.
The first two use filenames already suggested in your LaTeX draft:
figures/altitude_revisit.pdf
figures/revisit_maps.pdf

Activate or update the corresponding figure block. A sample is in
Overleaf_figures.txt. Use each figure label only once.

OUTPUT FIGURES
altitude_revisit: two panels for regional mean and worst observed gap.
revisit_maps: four maps with identical colour scale (per-target mean gap).
daily_coverage: daily region coverage for each altitude.
revisit_distribution: area-weighted distribution of per-target mean gaps.
observation_timeline: one target near 15 E, 50 N during the first 72 hours.
sampling_diagnostic: 10 s input vs 20 s subsampling (coarsening only).
ground_tracks: first-day subsatellite tracks; footprints are not shown.

OUTPUT TABLES
comparison_summary.csv: one row per altitude.
targets_*km.csv: each target's mean/max complete gap and edge intervals.
windows_*km.csv: observation-window start/end times, durations and clipping.
daily_coverage_*km.csv: one area-weighted coverage value per day.
coarse_20s_summary.csv: comparison using every other input sample.
analysis_metadata.json: inputs, hashes, configuration and geometry checks.

MODEL DEFINITION
Sensor: circular cone, half-angle 20 degrees (full FOV 40 degrees).
Boresight: geocentric nadir, along the satellite-to-Earth-centre vector.
Targets: WGS 84 geodetic coordinates, zero ellipsoidal height.
Geometry: satellite and target positions in EarthFixed; cone test plus the
outward ellipsoid-normal horizon test. No daylight, cloud or scheduling filter.
Region: provisional rectangle 5--25 degrees E and 45--55 degrees N, land AND
water. Grid: 0.5-degree cell centres, 800 points. Region weights approximate
cell areas on a sphere, as supplied by the earlier grid script.
All 30 daily bins start at the common UTC epoch 1 Jan 2026, 00:00:00.

The satellite's geocentric boresight and the ellipsoidal surface normals are
different vectors. The code keeps those definitions separate.

REVISIT CONVENTION
A window groups consecutive visible samples. Each internal start/end is
estimated at the midpoint between a visible and an invisible sample. This
is a sampling approximation, not exact continuous-time event location.
Revisit gap = start of next window minus end of previous window.
Mean gap is calculated for each target, then area-weighted across targets.
Worst observed gap is the largest complete gap over all targets.
Daily coverage is the area-weighted fraction with a window overlapping a day.
Target cells are represented by their centre points, not fully imaged cells.

Targets with fewer than two windows have no complete-gap estimate (NaN).
They are counted separately, not assigned zero revisit time. Leading and
trailing unobserved intervals are boundary-censored and reported separately;
they are not complete revisit gaps. No observations means the whole interval
is censored, not proof of an infinite revisit time.

CHECKS ALREADY RUN
Input durations, timestamps, initial radii and finite values checked.
Cone/horizon formula checked against independent direct-vector calculations,
nadir/antipodal examples and an analytic equatorial footprint boundary.
20-second coarsening performed on the 10-second visibility samples.

IMPORTANT NEXT CHECKS BEFORE FINAL CONCLUSIONS
Ten-second sampling can miss very short observation windows. Smaller changes
under coarsening do not prove fine-step convergence. The 400 km regional mean
changes by about 2.9% under 20 s coarsening, and its worst observed gap also
changes. Rerun GMAT at 5 s or finer to assess time-resolution convergence.
Repeat with a finer target grid and test the analysis duration and initial
orbital geometry. No such finer-grid, finer-time or orientation campaign is
claimed by this package.

The initial 500 km worst complete gap is approximately 420 hours despite a
much lower regional mean. Inspect the corresponding target/window table and
repeat at finer sampling before interpreting this extreme as robust.
A useful project result must discuss both typical and poorly served targets.

EXPECTED INITIAL SUMMARY (PROVISIONAL)
Altitude  Area-weighted mean gap (h)  Mean daily region coverage (%)
400       42.86                       46.98
500       28.51                       54.36
600       29.96                       61.67
700       26.30                       68.48

The data rank 700 km best on these two summary metrics for this configuration.
That does not establish a universally optimal orbit, daily full coverage,
a real imager's feasibility, or a result independent of the study assumptions.

SOURCE CREDIT
Country boundaries: Natural Earth Admin 0, 1:50m (public domain).
https://www.naturalearthdata.com/downloads/50m-cultural-vectors/
Country lines provide map context only; they do not define the study region.
